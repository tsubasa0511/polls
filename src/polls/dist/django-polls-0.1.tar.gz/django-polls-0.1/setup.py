from setuptools import setup, find_packages

setup()

